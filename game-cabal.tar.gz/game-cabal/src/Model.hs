{-# LANGUAGE InstanceSigs #-}
-- | This module contains the data types
--   which represent the state of the game
module Model where

import Graphics.Gloss
import Graphics.Gloss.Data.Vector
import Graphics.Gloss.Data.Point
import Graphics.Gloss.Geometry.Angle
import Graphics.Gloss.Interface.IO.Game
import qualified Graphics.Gloss.Data.Point.Arithmetic as GlossArithm

import qualified Data.Set as S
import System.Random
import Control.Monad

--------------------
-- Defines the game screen we are currently on
--------------------
data GameScreen = MainScreen | PlayScreen | PauseScreen | EndScreen deriving Eq

--------------------
-- Defines whether an entity is controlled by a human or by AI (further AI types can be added)
--------------------
data ShipType = Player | Enemy

--------------------
-- Defines whether the ship has its engine engaged or idle (to display the flame)
--------------------
data ShipState = Idle | Propeling

--------------------
-- Defines the bounding box for an entity, simplifies collision detection
--------------------
data BoundingBox = Bound { leftUpper :: Point,
                           rightBottom :: Point }

--------------------
-- Defines a spaceship (player or enemy) and its properties
--------------------
data Spaceship = Ship { shipPosition :: Point,
                        shipSpeed :: Vector,
                        shipAngle :: Float,
                        shipBoundingBox :: BoundingBox,
                        shipType :: ShipType,
                        shipState :: ShipState }

--------------------
-- Defines an asteroid and its properties
--------------------
data Asteroid = As { asPosition :: Point,
                     asSpeed :: Vector,
                     asBoundingBox :: BoundingBox,
                     asSize :: Float }

--------------------
-- Defines a missile (a single shot) and its properties
--------------------
data Missile = Msl { mslPosition :: Point,
                     mslSpeed :: Vector,
                     mslBoundingBox :: BoundingBox,
                     mslLifetime :: Float }

--------------------
-- Contains the players name and score in the current game
--------------------
data GameStats = Stats { name :: String,
                         score :: Int }

--------------------
-- Encapsulates all the game objects (spaceships, asteroids, missiles) into one container
--------------------
data GameObjects = GameObjs { asteroids :: [Asteroid],
                              missiles :: [Missile],
                              enemies :: [Spaceship],
                              player :: Spaceship }

--------------------
-- Contains all information about the game and its state
--------------------
data GameState = State { gameScreen :: GameScreen,
                         randomGen     :: StdGen,
                         gameScore :: Int,
                         gameObjects :: GameObjects,
                         gameKeys :: S.Set SpecialKey }

--------------------
-- Allows objects to move
--------------------
class Movable a where
  move :: a -> a

--------------------
-- Allows objects to be rendered
--------------------
class Renderable a where -- possibly remove this since its not used?
  render :: a -> Picture

instance Movable Spaceship where
  move :: Spaceship -> Spaceship
  move ship = ship { shipPosition = moveVec oldPos spd, shipSpeed = applyDrag (shipSpeed ship) }
    where
      oldPos = shipPosition ship
      spd = shipSpeed ship

instance Movable Asteroid where
  move :: Asteroid -> Asteroid
  move as = as { asPosition = moveVec oldPos spd, asSpeed = asSpeed as }
    where
      oldPos = asPosition as
      spd = asSpeed as

instance Movable Missile where
  move :: Missile -> Missile
  move msl = msl { mslPosition = moveVec oldPos spd, mslSpeed = applyDrag (mslSpeed msl) }
    where
      oldPos = mslPosition msl
      spd = mslSpeed msl

--------------------
-- Moves a point by a vector. Keeps the point within the screen boundaries, hardcoded for now (TODO)
--------------------
moveVec :: Point -> Vector -> Point
moveVec pt vec | newX < 0 = (1280, newY)
               | newX > 1280 = (0, newY)
               | newY < 0 = (newX, 720)
               | newY > 720 = (newX, 0)
               | otherwise = (newX, newY)
  where newX = fst pt + fst vec
        newY = snd pt + snd vec

--------------------
-- Returns the initial state of the game
--------------------
initialState :: IO GameState
initialState
  = do randGen           <- getStdGen
       let gs = State {
         gameScreen = MainScreen,
         randomGen = randGen,
         gameScore = 0,
         gameObjects = GameObjs { asteroids = [], missiles = [], enemies = [],
         player = createShip Player (640, 360)},
         gameKeys = S.empty
         }
       return (iterate addRandomAsteroid gs !! 0)

--------------------
-- Creates a new ship (player/enemy) at the given point
--------------------
createShip :: ShipType -> Point -> Spaceship
createShip tpe pt = Ship pt (0.0, 0.0) 0 (Bound upperLeft bottomRight) tpe Idle
    where
      upperLeft   = ((fst pt)-15,(snd pt)+10)
      bottomRight = ((fst pt)+15,(snd pt)-10)
--------------------
-- Creates random enemies
--------------------
addRandomEnemies :: GameState -> GameState
addRandomEnemies gs = gs{gameObjects = updatedObjects , randomGen = updatedRandom }
    where (pos, updatedRandom)      = getRandomCoordinates (randomGen gs)
          newEnemy                  = createShip Enemy pos
          go                        = gameObjects gs
          updatedObjects            = go{ enemies = newEnemy : (enemies go)}
--------------------
-- Creates an asteroid of the given size at the given point
--------------------
createAsteroid :: Float -> Point -> Vector -> Asteroid
createAsteroid size pt spd = As pt spd (Bound upperLeft bottomRight) size
    where
      upperLeft   = (((fst pt)-200)*size,((snd pt)+200)*size)
      bottomRight = (((fst pt)+200)*size,((snd pt)-200)*size)
--createAsteroid size pt spd = As pt spd (Bound (0.0, 0.0) (0.0, 0.0)) size
--------------------
-- Tuple containing the X range of the game field
--------------------
gameRangeX :: (Float,Float)
gameRangeX = (0,1280)
--------------------
-- Tuple containing the Y range of the game field
--------------------
gameRangeY :: (Float,Float)
gameRangeY = (0,720)
--------------------
-- Tuple containing the speed range of a ship
--------------------
shipSpeedRange :: (Float,Float)
shipSpeedRange = (-7,7)
--------------------
-- Tuple containing the speed range of an asteroid
--------------------
asteroidSpeedRange :: (Float,Float)
asteroidSpeedRange = (-3,3)
--------------------
-- Tuple containing the size range of an asteroid
--------------------
asteroidSizeRange :: (Float,Float)
asteroidSizeRange = (0.2,1)
--------------------
-- Returns random size for an asteroid
--------------------
getRandomSize :: RandomGen g => g -> (Float, g)
getRandomSize g = randomR asteroidSizeRange g
--------------------
-- Returns random coordinate in the game field
--------------------
getRandomCoordinates :: RandomGen g => g -> (Point, g)
getRandomCoordinates g
  = ((x, y), g2)
    where (x, g1) = randomR gameRangeX g
          (y, g2) = randomR gameRangeY g1
--------------------
-- Returns random speed for asteroids
-------------------
getRandomAsteroidSpeed :: RandomGen g => g -> (Vector, g)
getRandomAsteroidSpeed g
  = ((dx, dy), g2)
    where (dx, g1) = randomR asteroidSpeedRange g
          (dy, g2) = randomR asteroidSpeedRange g1
--------------------
-- Adds random asteroids to the game field
-------------------
addRandomAsteroid :: GameState -> GameState
addRandomAsteroid gs = gs{gameObjects = updatedObjects , randomGen = updatedRandom }
    where (pos,   g1)               = getRandomCoordinates (randomGen gs)
          (speed, g2)               = getRandomAsteroidSpeed g1
          (sizeA, updatedRandom)    = getRandomSize g2
          newAsteroid               = createAsteroid sizeA pos speed
          go                        = gameObjects gs
          updatedObjects            = go{ asteroids = newAsteroid : (asteroids go)}
--------------------
-- Create a missile heading in the direction of the spaceship
--------------------
createMissile :: Spaceship -> Missile
createMissile ship = Msl (0.0, 0.0) (2.0, 2.0) (Bound (0.0, 0.0) (0.0, 0.0)) 100

--------------------
-- Adds a missile to the list of missiles in the gameObject
--------------------
addMissile :: GameObjects -> Missile -> GameObjects
addMissile gobj msl = gobj { missiles = msl : missiles gobj}

--------------------
-- Starts the engine of the ship to propel it forward
--------------------
propelShip :: Spaceship -> Spaceship
propelShip s = s { shipSpeed = newSpd, shipState = Propeling }
      where spd = shipSpeed s
            spdVal = rotateV (degToRad (shipAngle s)) (1, 0)
            newSpd = limitSpeed (fst spd + fst spdVal, snd spd - snd spdVal)

--------------------
-- Limits the speed to stay in between reasonable values
--------------------
limitSpeed :: Vector -> Vector
limitSpeed spd = (newX, newY)
  where x = fst spd
        y = snd spd
        newX = min (max x (-10)) 10
        newY = min (max y (-10)) 10

--------------------
-- Applies drag to speed, gradually slowing an entity down
--------------------
applyDrag :: Vector -> Vector
applyDrag spd = (x + xdrag, y + ydrag)
  where x = fst spd
        y = snd spd
        xdrag | x == 0 = 0
              | x > 0 = -0.1
              | otherwise = 0.1
        ydrag | y == 0 = 0
              | y > 0 = -0.1
              | otherwise = 0.1

--------------------
-- Stops the engine of the ship
--------------------
idleShip :: Spaceship -> Spaceship
idleShip s = s { shipState = Idle }

--------------------
-- Checks whether two bounding boxes collide --TODO change to polygon-based collision checking
--------------------
checkCollisionPA :: Spaceship -> Asteroid-> Bool
checkCollisionPA p a = magV ((asPosition a) GlossArithm.- (shipPosition p)) < (200*(asSize a))
--------------------
-- Checks whether the player and a missile collide
--------------------
checkCollisionMP :: Spaceship -> Missile-> Bool
checkCollisionMP p m = magV ((mslPosition m) GlossArithm.- (shipPosition p)) < 15
--------------------
-- Checks whether an asteroid and a missile collide
--------------------
checkCollisionAM :: Asteroid -> Missile-> Bool
checkCollisionAM a m = magV ((asPosition a) GlossArithm.- (mslPosition m)) < (200*(asSize a))
--------------------
-- Changes the spaceship angle and rotates the bounding box (graphic rotation is handled separately)
--------------------
rotateShip :: Spaceship -> Float -> Spaceship
rotateShip s rot = s { shipAngle = shipAngle s + rot }

--------------------
-- Turns the spaceship to face a specified point on screen
--------------------
turnToFace :: Spaceship -> Point -> Spaceship
turnToFace ship pt = ship { shipAngle = radToDeg((atan2 (shipy - pty) (shipx - ptx)) - pi) }
  where spos = shipPosition ship
        shipx = fst spos
        shipy = snd spos
        ptx = fst pt
        pty = snd pt

--------------------
-- Whenever an asteroid is hit, explode it into smaller asteroids (or none if its too small)
--------------------
-- TODO rewrite to use the better randomness
explodeAsteroid :: Asteroid -> IO [Asteroid]
explodeAsteroid as | asSize as > 5 = do
                        cnt <- randomRIO(2, 4)
                        sgnx <- randomRIO(-1, 1)
                        sgny <- randomRIO(-1, 1)
                        spdx <- randomRIO(1, 4)
                        spdy <- randomRIO(1, 4)
                        pure $ replicate cnt (createAsteroid (asSize as / 2) (asPosition as) (sgnx * spdx, sgny * spdy))
                   | otherwise = pure []

--------------------
-- Updates the position of the missiles and remove them if their lifetimes are over
--------------------
updateMissiles :: [Missile] -> [Missile]
updateMissiles msls = map move
                      (filter (\n -> mslLifetime n > 0)
                      (map (\m -> m { mslLifetime = mslLifetime m - 1}) msls))

--------------------
-- Terminates the current game, saves the highscore if it is above the old ones and displays the gameOver screen
--------------------
gameOver :: GameState -> GameState
gameOver gstate = gstate { gameScreen = EndScreen }
-- TODO call saveHighscore

--------------------
-- If the current score is higher than the saved highscore, rewrite it
--------------------
saveHighscore :: GameState -> IO ()
saveHighscore gstate = do
                          oldHigh <- readHighscore
                          Control.Monad.when (newHigh > oldHigh) (writeFile "highscore.txt" (show newHigh))
                       where newHigh = gameScore gstate

--------------------
-- Reads the current highscore stored in the highscore.txt file
--------------------
readHighscore :: IO Int
readHighscore = do
                  txt <- readFile "highscore.txt"
                  return (read txt::Int)
