-- | This module defines how to turn
--   the game state into a picture
module View where

import Graphics.Gloss
import Model

--------------------
-- Main rendering method. Based on game state determines the correct screen to render
--------------------
view :: GameState -> IO Picture
-- todo figure out rendering positions
view gstate = pure $ case gameScreen gstate of
                MainScreen -> renderMainScreen gstate
                PlayScreen -> renderPlayScreen gstate
                PauseScreen -> renderPauseScreen gstate
                EndScreen -> renderEndScreen gstate

--------------------
-- Renders the first screen with game logo and player name input
--------------------
renderMainScreen :: GameState -> Picture
renderMainScreen _ = translate (-380) 0 $ color white (text "Main Screen")

--------------------
-- Pause screen - displays the score and a message that the game is paused
--------------------
renderPauseScreen :: GameState -> Picture
renderPauseScreen gstate = translate (-230) 20 $ pictures [color white (text "Paused"), getStatsText gstate]

--------------------
-- Renders the game itself - player, enemies, asteroids, missiles and score
--------------------
renderPlayScreen :: GameState -> Picture
renderPlayScreen gState = translate (-640) (-360) $ pictures ( [mPlayer,mScore] ++ mEnemies ++ mAsteroids )
                where
                  mPlayer = renderPlayer red (player(gameObjects gState))
                  listEnemies = enemies (gameObjects gState)
                  mEnemies = map (renderPlayer green) listEnemies
                  listAsteroids = asteroids (gameObjects gState)
                  mAsteroids = map (renderAsteroids cyan) listAsteroids
                  listMissiles = missiles (gameObjects gState)
                  mMissiles = map (renderMissiles yellow) listMissiles
                  mScore = getStatsTextGame gState
                  
--------------------
-- Converts current game stats (name and score) into a picture
--------------------
getStatsTextGame :: GameState -> Picture
getStatsTextGame gstate = translate (20) (80) (scale 0.5 0.5 (getStatsText gstate))

--------------------
-- Renders the player
--------------------
renderPlayer :: Color -> Spaceship -> Picture
renderPlayer c p = translate x y (rotate angle (pictures [playerShape, flame]))
            where
                playerShape = Color c (Polygon [(-15,-10), (-15,10), (15,0)])
                (x,y) = shipPosition p
                angle = shipAngle p
                flame = case shipState p of{Idle -> blank;
                                            Propeling -> Translate (-15) 0 (Scale 1 1 (Color yellow (Polygon [(4,7),(-4,0),(4, -7)])))}

--------------------
-- Renders the Asteroid
--------------------
renderAsteroids :: Color -> Asteroid -> Picture
renderAsteroids c a =  translate x y (scale size size (pictures [asteroidShape]))
            where
              asteroidShape = Color c (Polygon [(0.0, 200.0),(200.0, 100.0), (200.0, -100.0),(0.0,-200.0), (-200.0, -100.0),(-200.0, 100.0)])
              (x,y) = asPosition a
              size  = asSize a
------------------
-- Renders the Asteroid
-------------------
renderMissiles :: Color -> Missile -> Picture
renderMissiles c m =  translate x y (pictures [missileShape])
                where
                 missileShape = Color c (Circle 3)
                 (x,y) = mslPosition m

--------------------
-- End screen - displays "game over", players name and final score
--------------------
renderEndScreen :: GameState -> Picture
renderEndScreen gstate = pictures [color white (text "Game over!"), getStatsText gstate]

--------------------
-- Converts current game stats (name and score) into a picture
-- TODO Name has been hidden, decide whether to keep it or remove it alltogether
--------------------
getStatsText :: GameState -> Picture
getStatsText gstate = translate 0 (-120) $ color white (text ("Score:" ++ show (gameScore gstate)))
