-- | This module defines how the state changes
--   in response to time and user input
module Controller where

import Model

import Graphics.Gloss
import Graphics.Gloss.Interface.IO.Game

import qualified Data.Set as S
import System.Random
import Data.Char

--------------------
-- Update loop - only update the game if the game is running, determined by the gameScreen we are in
--------------------
step :: Float -> GameState -> IO GameState
step secs gstate | gameScreen gstate == PlayScreen = pure (updateGame secs gstate)
                 | otherwise = pure gstate

--------------------
-- Updates the AI, all game objects and then performs collision checking
--------------------
updateGame :: Float -> GameState -> GameState
updateGame secs gstate = performCollisions (gstate { gameObjects = updateGameObjects (gameObjects (updateAI (handleKeys gstate))) })

--------------------
-- Updates all the objects in the game (performs movement and roatation)
--------------------
updateGameObjects :: GameObjects -> GameObjects
updateGameObjects gobjs = gobjs { asteroids = map move (asteroids gobjs),
                                  missiles = updateMissiles (missiles gobjs),
                                  enemies = map move (enemies gobjs),
                                  player = move (player gobjs) }

--------------------
-- Handle user input
--------------------
input :: Event -> GameState -> IO GameState
input e gstate = return (inputKey e gstate)

--------------------
-- Handle keypresses
--------------------
inputKey :: Event -> GameState -> GameState
inputKey (EventKey (SpecialKey key) Down _ _) gstate = case key of

  -- ESC to go to main screen
  KeyEsc -> gstate { gameScreen = MainScreen }

  -- Enter on main screen to start game
  KeyEnter -> case gameScreen gstate of
                MainScreen -> gstate { gameScreen = PlayScreen }
                EndScreen ->{-initialState-}gstate { gameScreen = EndScreen }
                _ -> gstate

  -- All other keys get added to keypress array
  _ -> gstate { gameKeys = S.insert key (gameKeys gstate) }

inputKey (EventKey (Char c) Down _ _) gstate = case toUpper c of
  -- P to pause/unpause the game
  'P' -> case gameScreen gstate of
          PlayScreen -> gstate { gameScreen = PauseScreen }
          PauseScreen -> gstate { gameScreen = PlayScreen }
          _ -> gstate
  'A' -> (addRandomAsteroid gstate) -- Adds random asteroids TODO: to remove just for debug
  -- Space to fire (simulates F1 for convenience)
  'E' -> (addRandomEnemies gstate) -- Adds random enemies TODO: to remove just for debug
  ' ' -> gstate { gameKeys = S.insert KeyF1 (gameKeys gstate) }

  _ -> gstate

-- Handle keys being released. Also specific events upon key release
inputKey (EventKey (SpecialKey key) Up _ _) gstate = case key of
  -- workaround to disable the flame here. TODO make this less ugly
  KeyUp -> case gameScreen gstate of
    PlayScreen -> gstate { gameObjects = (gameObjects gstate) { player = idleShip (player (gameObjects gstate)) }, gameKeys = S.delete key (gameKeys gstate) }
    _ -> gstate { gameKeys = S.delete key (gameKeys gstate) }

  _ -> gstate { gameKeys = S.delete key (gameKeys gstate) }

-- Handles releasing spacebar (interally represented as F1)
inputKey (EventKey (Char c) Up _ _) gstate = case toUpper c of
  ' ' -> gstate { gameKeys = S.delete KeyF1 (gameKeys gstate) }

  _ -> gstate

-- Handling mouse presses
inputKey (EventKey (MouseButton LeftButton) Down _ (_, _)) gstate = gstate { gameKeys = S.insert KeyUp (gameKeys gstate) } --simulate up arrow press
inputKey (EventKey (MouseButton LeftButton) Up _ (_, _)) gstate = gstate { gameObjects = (gameObjects gstate) { player = idleShip (player (gameObjects gstate)) }, gameKeys = S.delete KeyUp (gameKeys gstate) } --simulate up arrow release + flame workaround (TODO make prettier)

inputKey (EventKey (MouseButton RightButton) Down _ (_, _)) gstate = gstate { gameKeys = S.insert KeyF1 (gameKeys gstate) } --simulate F1 press
inputKey (EventKey (MouseButton RightButton) Up _ (_, _)) gstate = gstate { gameKeys = S.delete KeyF1 (gameKeys gstate) } --simulate F1 release

-- When mouse movement is detected, orient the player to face the mouse
inputKey (EventMotion pt) gstate = gstate { gameObjects = (gameObjects gstate) { player = turnToFace (player (gameObjects gstate)) pt } }

inputKey _ gstate = gstate

handleKeys :: GameState -> GameState
handleKeys gstate = foldr handleKey gstate (gameKeys gstate)

handleKey :: SpecialKey -> GameState -> GameState
handleKey KeyUp gstate = case gameScreen gstate of
  PlayScreen -> gstate { gameObjects = (gameObjects gstate) { player = propelShip (player (gameObjects gstate)) } }
  _ -> gstate

handleKey KeyLeft gstate = case gameScreen gstate of
  PlayScreen -> gstate { gameObjects = (gameObjects gstate) { player = rotateShip (player (gameObjects gstate)) (-5) } }
  _ -> gstate

handleKey KeyRight gstate = case gameScreen gstate of
  PlayScreen -> gstate { gameObjects = (gameObjects gstate) { player = rotateShip (player (gameObjects gstate)) 5 } }
  _ -> gstate

handleKey KeySpace gstate = case gameScreen gstate of
  PlayScreen -> gstate { gameObjects = addMissile (gameObjects gstate) (createMissile (player (gameObjects gstate))) }
  _ -> gstate

handleKey _ gstate = gstate

--------------------
-- AI determines the actions for enemy spaceships
--------------------
updateAI :: GameState -> GameState
updateAI gstate = gstate { gameObjects = gobjs { enemies = map (enemyAction (shipPosition plr)) enms }}
           where
            gobjs = gameObjects gstate
            enms = enemies gobjs
            plr = player gobjs

--------------------
-- Based on player position, determine what the enemy should do (rotation, propeling, possibly shooting)
--------------------
enemyAction :: Point -> Spaceship -> Spaceship
enemyAction playerPos enemy = if distance > 100 then propelShip turnedEnemy else turnedEnemy
                            where
                              distance = pointDistance playerPos (shipPosition enemy)
                              turnedEnemy = turnToFace enemy playerPos

--------------------
-- Computes the euclidian distance between two points
--------------------                                
pointDistance :: Point -> Point -> Float
pointDistance (x1, y1) (x2, y2) = sqrt (x' * x' + y' * y')
                                  where
                                    x' = x1 - x2
                                    y' = y1 - y2

--------------------
-- Performs collisions on all game entities
--------------------
performCollisions :: GameState -> GameState
performCollisions gstate = collisionsAsteroidMissile (collisionsMissileEnemies (collisionsMissilePlayer (collisionsAsteroidPlayer gstate)))

--------------------
-- Resolves collisions between all missiles and all asteroids
--------------------
resolveCollisionAM::[Asteroid] -> [Missile] -> [Asteroid]
resolveCollisonAM [] _    = []
resolveCollisionAM xs []  = xs
resolveCollisionAM xs ks  = [x | x<-xs ,k<-ks,not(checkCollisionAM x k)]

collisionsAsteroidMissile :: GameState -> GameState
collisionsAsteroidMissile gstate = gstate{ gameObjects = newgo}
    where
      go  = gameObjects gstate
      newgo = go {asteroids = resolveCollisionAM (asteroids go) (missiles go)}

 --TODO
-- For every missile, check whether it collides with an asteroid. If so,
-- remove that asteroid from the list and append the result of explodeAsteroid.
-- Also add score for every destroyed asteroid.
resolveCollisionPA::[Asteroid] -> Spaceship -> Bool
resolveCollisionPA [] pl  = False
resolveCollisionPA xs pl  = any (\x -> checkCollisionPA pl x) xs

collisionsAsteroidPlayer :: GameState -> GameState
collisionsAsteroidPlayer gstate | (resolveCollisionPA ast pl ) == True = gstate{ gameScore = (gameScore gstate)+1}
                                | otherwise                            = gstate
    where go = gameObjects gstate
          pl = player go
          ast = asteroids go
   --TODO
-- For every asteroid, check whether it collides with the player. If so,
-- end the game
resolveCollisionMP::[Missile] -> Spaceship -> Bool
resolveCollisionMP [] pl  = False
resolveCollisionMP xs pl  = any (\x -> checkCollisionMP pl x) xs
collisionsMissilePlayer :: GameState -> GameState
collisionsMissilePlayer gstate | (resolveCollisionMP miss pl ) == True = gameOver gstate
                               | otherwise                             = gstate
    where go = gameObjects gstate
          pl = player go
          miss = missiles go
-- For every missile, check whether it collides with the player. If so,
-- end the game
--------------------
-- Resolves collisions between all missiles and all asteroids
--------------------
resolveCollisionME::[Spaceship] -> [Missile] -> [Spaceship]
resolveCollisonME [] _    = []
resolveCollisionME xs []  = xs
resolveCollisionME xs ks  = [x | x<-xs ,k<-ks,not(checkCollisionMP x k)]

collisionsMissileEnemies :: GameState -> GameState
collisionsMissileEnemies gstate =gstate{ gameObjects = newgo}
    where
      go  = gameObjects gstate
      newgo = go {enemies = resolveCollisionME (enemies go) (missiles go)}
-- For every missile, check whether it collides with an enemy. If so,
-- remove it from the list of enemies. Add score for every destroyed enemy
